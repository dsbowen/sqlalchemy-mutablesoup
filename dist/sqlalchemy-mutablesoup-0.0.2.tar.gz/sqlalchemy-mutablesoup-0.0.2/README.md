# SQLAlchemy-MutableSoup

SQLAlchemy-MutableSoup defines a mutable BeautifulSoup SQLAlchemy database type.

## License

This project is licensed under the MIT License [LICENSE](https://github.com/dsbowen/sqlalchemy-mutablesoup/blob/master/LICENSE).